package iartes.icomp.pet_system_final;
import static iartes.icomp.pet_system_final.R.id.*;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.AbsListView;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;

import iartes.icomp.pet_system_final.Info_Fragment;
import iartes.icomp.pet_system_final.R;
import iartes.icomp.pet_system_final.Setting_Fragment;
import iartes.icomp.pet_system_final.Share_Fragment;
import iartes.icomp.pet_system_final.home_fragment;


public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private SQLiteDatabase banco_pet;
    public AbsListView.RecyclerListener listViewDados;

    private DrawerLayout drawerLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listViewDados = (AbsListView.RecyclerListener) findViewById(rcv_dados);

        criarBancoPet();
        listarBancoPet();

        Toolbar toolbar = findViewById(R.id.toolbar); //Ignore red line errors
        setSupportActionBar(toolbar);
        drawerLayout = findViewById(drawer_layout);
        NavigationView navigationView = findViewById(nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open_nav,
                R.string.close_nav);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction().replace(fragment_container, new home_fragment()).commit();
            navigationView.setCheckedItem(nav_home);
        }
    }

    @Override


    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();
        if (itemId == nav_home) {
            getSupportFragmentManager().beginTransaction().replace(fragment_container, new home_fragment()).commit();
        } else if (itemId == nav_settings) {
            getSupportFragmentManager().beginTransaction().replace(fragment_container, new Setting_Fragment()).commit();
        } else if (itemId == nav_share) {
            getSupportFragmentManager().beginTransaction().replace(fragment_container, new Share_Fragment()).commit();
        } else if (itemId == nav_about) {
            getSupportFragmentManager().beginTransaction().replace(fragment_container, new Info_Fragment()).commit();
        } else if (itemId == nav_logout) {
            Toast.makeText(this, "Logout!", Toast.LENGTH_SHORT).show();
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }
    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    public void criarBancoPet(){

        try {

            banco_pet = openOrCreateDatabase("db_pet",MODE_PRIVATE,null);
            banco_pet.execSQL("CREATE TABLE IF NOT EXISTS tb_principal("+
                    " id INTEGER PRIMARY KEY AUTOICREMENT"+
                    ",motivo VARCHAR"+
                    ",tipo_animal VARCHAR"+
                    ",idade VARCHAR"+
                    ",contato VARCHAR"+
                    ",descricao VARCHAR"+
                    ",imagem BLOB)");
            banco_pet.close();
        } catch (Exception e){
            e.printStackTrace();

        }

    }

    public void listarBancoPet(){

        try {
            banco_pet = openOrCreateDatabase("db_pet",MODE_PRIVATE,null);
            Cursor cursor = banco_pet.rawQuery("SELECT * FROM tb_principal",null);
            ArrayList<String> linhas = new ArrayList<String>();
            ArrayAdapter adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, linhas);





        }catch (Exception e){
            e.printStackTrace();
        }

    }
}